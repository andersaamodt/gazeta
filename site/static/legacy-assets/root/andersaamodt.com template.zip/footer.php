			</div>
		</div>
		<div class="section group">
			<div id="footer">
				<p><a href="http://validator.w3.org/check?uri=referer">Validate XHTML</a></p>
			</div>
		</div>
	</body>
</html>