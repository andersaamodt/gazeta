<?php include("header.php"); ?>
<?php include("banner.php"); ?>

<h1>Oeuvre</h1>
<p style="text-indent: 0;">This page is a catalog of my writing and other completed works.</p>
<h2>2017</h2>
<ul>
	<li><a href="https://docs.google.com/document/d/1Hum7eQ5WAwrHmFL2t7R1UBg_fElAsxjfrZTXb8UcdvU/edit?usp=sharing">The Real S.H.I.E.L.D.: Why you should be watching <em>Marvel's Agents of S.H.I.E.L.D.</em> and using it as a Holochain playbook</a></li>
	<li><a href="https://docs.google.com/document/d/1aLa-uIoUXJOyL0LqLssRY9Fmi4ufMXVm2qhfqoZk7Zo/edit?usp=sharing">Holochain Application Developer Educational Outreach Framework</a></li>
	<li><a href="https://docs.google.com/document/d/1e2JcOdYEbWCtffDTXOZALXgS1nfC0KaDyyaqjyPklB0/edit?usp=sharing">Holoptic Hackathons for Optimum Community Growth</a></li>
	<li><a href="http://andersaamodt.com/binder.php">Decentralized Organizer's Binder</a>, several one-pagers so far</li>
	<li><a href="https://www.reddit.com/r/sorceryofthespectacle/comments/7096fy/the_snow_crash_bees_code_386/">The Snow B.E.E.S. and Code 386</a></li>
	<li><a href="https://www.reddit.com/r/sorceryofthespectacle/comments/6ur5ji/bees_and_colony_collapse_disorder_ccd/">B.E.E.S. and Colony Collapse Disorder</a> (hyperfiction)</li>
	<li><a href="oeuvre/TEAM%20Briefing%202017.pdf">T.E.A.M. Briefing 2017</a> (<a href="https://www.reddit.com/r/sorceryofthespectacle/comments/5sd92y/team_briefing_2017/">reddit thread</a> | <a href="oeuvre/TEAM%20Briefing%202017.md">.md version</a>)</li>
	<li><a href="https://www.reddit.com/r/sorceryofthespectacle/comments/5p817e/what_is_ceptr/dcqnk11/">What is Ceptr?</a> (reddit comment)</li>
</ul>
<h2>2016</h2>
<ul>
	<li><a href="oeuvre/delicate.php">delicate.txt</a> (short story)</li>
	<li><a href="oeuvre/app%20proposal.pdf">&ldquo;A mobile app designed to act as a contemplation device to support calm reflection, mind-wandering, and epiphanies&rdquo;</a>, a proposal for my longer-term <a href="http://patreon.com/crucible">Crucible</a> project</li>
	<li>Three Pamphlets on Friendship (<a href="oeuvre/friendship-pamphlet-00.pdf">One</a> | <a href="oeuvre/friendship-pamphlet-01.pdf">Two</a> | <a href="oeuvre/friendship-pamphlet-02.pdf">Three</a>)
</ul>
<h2>2015</h2>
<ul>
	<li><a href="decadence_v1.php">Decadence v1.0</a>, an implementation of the <a href="http://ccru.net">ccru</a>'s game</li>
	<li><a href="decadence.php">Decadence v2.0</a>, adding <a href="http://urbanomic.com/gematrix.html">Nummificator</a> functionality (unfinished)</li>
	<li><a href="http://internetschoolofmagic.com/classes.php">20 magic classes</a> at <a href="http://internetschoolofmagic.com">The Internet School of Magic</a></li>
	<li><a href="amphium.php">Amphium</a>, a quick demo of my longer-term <a href="http://patreon.com/crucible">Crucible</a> project</li>
	<li><a href="https://docs.google.com/document/d/1GbaY0NSFsG3_s2hvT0dxf8sD5JHfjNrtPWrPPWL7s5I/edit?usp=sharing">Letters on Critical Activism</a>, including two short essays:
		<ul>
			<li>But what are we going to actually DO about it?! Endless beginnings &amp; historical context: The problem of critical activism &amp; Isaac Asimov's Foundation series</li>
			<li>What would a healthy social model of news look like?</li>
		</ul>
	</li>
</ul>
<h2>2014</h2>
<ul>
	<li><a href="https://docs.google.com/document/d/1x5SXzacyO5Am4S_vGryeI-L4cM4zkWTaBO38tTUPkHA/edit?usp=sharing">Amphium: A contemplative grotto for self-reflection and strange-looping</a>, an earlier proposal for my longer-term <a href="http://patreon.com/crucible">Crucible</a> project, written as a grad school application</li>
	<li><a href="http://twitter.com/CriticalMLP">@CriticalMLP</a>, a humorous twitter I made to critique and analyze My Little Pony</li>
	<li>Is SotS Becoming...? series
		<ul>
			<li><a href="http://www.reddit.com/r/sorceryofthespectacle/comments/1ur2is/the_new_godzilla_a_slam_poem_i_wrote_after_my/">The New Godzilla</a></li>
			<li><a href="http://www.reddit.com/r/sorceryofthespectacle/comments/2ev2a7/the_game_we_are_playing/">The Game We Are Playing</a></li>
			<li><a href="http://www.reddit.com/r/sorceryofthespectacle/comments/2d7nvu/sophia_in_the_machine_the_mechanic_saboteur/">Sophia in the machine, the mechanic saboteur</a></li>
			<li><a href="http://www.reddit.com/r/sorceryofthespectacle/comments/2wd3lj/is_sots_becoming_an_alternate_reality_game_sots/">Is SotS becoming an ARG?</a></li>
			<li><a href="http://www.reddit.com/r/sorceryofthespectacle/comments/2x6gzm/is_sots_becoming_a_goddess_cult_sots_as_a/">Is SotS becoming a Goddess cult?</a></li>
			<li><a href="http://www.reddit.com/r/sorceryofthespectacle/comments/2z9llc/is_sots_becoming_a_revolutionary_cell_a_manifesto/">Is SotS becoming a revolutionary cell?</a></li>
			<li><a href="http://www.reddit.com/r/sorceryofthespectacle/comments/2zr384/is_sots_becoming_a_digital_drug_woah_woah_chill/">Is SotS becoming a digital drug?</a></li>
			<li><a href="https://www.reddit.com/r/sorceryofthespectacle/comments/31sio8/is_sots_becoming_a_spectacle_answer_yes/">Is SotS becoming a spectacle?</a></li>
		</ul>
	</li>
	<li><a href="https://docs.google.com/document/d/1u5x9JXUKv-_8xDKb05mAZEoCTXqY7562P_q6isbFTLA/edit?usp=sharing">Read This First: Tools for Critical Activism</a></li>
	<li><a href="https://docs.google.com/document/d/1AUneTvcmrVqv3mFEeHRylM70kuecjLg4xMYyToT5P2s/edit?usp=sharing">Unleashing the Numogram</a>, a book-in-progress</li>
</ul>
<h2>2013</h2>
<ul>
	<li><a href="https://docs.google.com/document/d/17E9_Z7xT_-zRZveR-4xqfwJOfOjxs5fCR9ux98Wjxvw/edit?usp=sharing">The Politics of Reality: Collected Essays</a>, a collection of essays written around this time at Michigan State University
		<ul>
			<li>When Worlds Collide: Multiple Reality and Education</li>
			<li>Ranciere’s Distribution of the Sensible and the Choice to Live in the Mythos of Our Choosing (reddit post 2015)</li>
			<li>Combatting Lateral Distributed Processing of Topics of Conversation (reddit post 2015)</li>
			<li>So, Is This a Subreddit to Memetically Engineer Society? (reddit post 2015)</li>
			<li>The Ethics of Virulent Curriculum</li>
			<li>My Personal Curriculum: Reflections on Autodidacticism and the Psychogeography of Curriculum (2013)</li>
		</ul>
	</li>
</ul>
<h2>2012</h2>
<ul>
	<li><a href="https://www.youtube.com/watch?v=DnhO8LHt46s">Multimodal Music &amp; the Coming Technopocalypse</a> (9min video)</li>
</ul>
<h2>2010</h2>
<ul>
	<li><a href="oeuvre/The%20Exciting%20World%20of%20Competitive%20High%20School%20Eating.pdf">The Exciting World of Competitive High School Eating</a>, an essay written for a neuroscience of motivation class</li>
</ul>
<?php include("footer.php"); ?>