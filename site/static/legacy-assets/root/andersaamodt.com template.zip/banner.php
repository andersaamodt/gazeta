<div class="alphabox" style="float: right; padding-left: 1em; padding-right: 1em; margin-bottom: 0.5em; margin-left: 0.5em;">
	<p style="text-align: right; margin: 0;"><a href="http://patreon.com/crucible"><img src="patreon-button.png" alt="A button linking to my Patreon donate page" width="200" style="margin: 1.4em 0 0 0;" /></a></p>
	<p style="text-align: right; margin: 0.5em 4.1em 0 0; font-size: 0.95em;"><a href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&amp;hosted_button_id=CTB5J2UB98AH6">Send PayPal</a></p>
	<p style="text-align: right; margin: 0 4.35em 0em 0; font-size: 0.95em;"><a href="#" onclick="if(document.getElementById('etherId').style.display=='none') { document.getElementById('etherId').style.display='block'; } else { document.getElementById('etherId').style.display='none'; } return false;">Send Ether</a></p>
	<p style="display: none; text-align: right; margin: 0; font-size: 0.95em;" id="etherId">0xe7da632f05c5ac216eec3e4e6abe777d1ddcc47d</p>
	<p style="text-align: right; margin: 0 3.73em 0em 0; font-size: 0.95em;"><a href="#" onclick="if(document.getElementById('bitcoinId').style.display=='none') { document.getElementById('bitcoinId').style.display='block'; } else { document.getElementById('bitcoinId').style.display='none'; } return false;">Send Bitcoin</a></p>
	<p style="display: none; text-align: right; margin: 0; font-size: 0.95em;" id="bitcoinId">12yEnjCWwJNZfdMap7urz6J5s8eNMVz3Rb</p>
</div>
<div class="contentcontainer">
	<div id="banner">Anders J. Aamodt</div>
	<div class="alphabox" id="tabbar">
		<ul>
		<?php
			// output a navbar, with the current page not linked
			for($i = 0; $i < count($names); $i++) {
				$name = $names[$i];
				$link = $links[$i];
				$this_page = trim($_SERVER["PHP_SELF"], "/");
				//$name = split("[.]", $link)[0];
				if($this_page == 'index.php') {
					$this_page = '/';
				}
				if ($link != $this_page) {
					echo "<li><a href=\"" . $link . "\">" . $name . "</a></li>";
				} else {
					echo "<li class='current'>" . $name . "</li>";
				}
			}
		?>
		</ul>
	</div>
	<div id="content" class="alphabox">