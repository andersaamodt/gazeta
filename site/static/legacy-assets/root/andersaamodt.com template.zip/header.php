<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php
	$names = ["Contact", "Projects", "Oeuvre"];
	$links = ["/", "projects.php", "oeuvre.php"];
	$this_page = trim($_SERVER["PHP_SELF"], "/");
?>
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="google-site-verification" content="OitftAoQ5E7PKeUupCAnxIVwK_TbYe0sGKuzdlkwJJU" />
		<link href="style.css" rel="stylesheet" type="text/css" />
		<title>Anders J. Aamodt - <?php echo ucwords($names[array_search($this_page, $links)]); ?></title>
		<script type="text/javascript">
			(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
			(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
			m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
			})(window,document,'script','//www.google-analytics.com/analytics.js','ga');
			ga('create', 'UA-63785131-1', 'auto');
			ga('send', 'pageview');
		</script>
		<!-- Photo Gallery includes -->
		<link rel="stylesheet" type="text/css" href="css/rebase-min.css" />
		<link rel="stylesheet" type="text/css" href="css/style.css" />
		<link rel="stylesheet" type="text/css" href="resources/UberGallery.css" />
		<link rel="stylesheet" type="text/css" href="resources/colorbox/1/colorbox.css" />
		<link href="https://fonts.googleapis.com/css?family=Share+Tech+Mono|Crimson+Text|Play|Armata" rel="stylesheet" />
		<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
		<script type="text/javascript" src="resources/colorbox/jquery.colorbox.js"></script>
		<script type="text/javascript">
			$(document).ready(function() {
				$("a[rel='photos']").colorbox({maxWidth: "90%", maxHeight: "90%", opacity: ".5"});
			});
		</script>
	</head>
	<body>