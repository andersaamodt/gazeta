<?php include("header.php"); ?>
<?php include("banner.php"); ?>

<h1>Projects</h1>
<p style="text-indent: 0;">Here are my current major projects:</p>
<ul>
	<li><a href="http://holochain.org">Holochain</a>, hackathon organizer &amp; online community coordinator via <a href="http://holo.host">Holo</a>
		<ul>
			<li><a href="http://map.holohackers.org">the Map</a>, a timeline of all app ideas</li>
			<li><a href="http://holohackers.org">holohackers.org</a>, a quick menu of Holochain developer resources</li>
		</ul>
	</li>
	<li><a href="http://memesofproduction.net">The Memes of Production</a> podcast</li>
	<li><a href="http://coalitionofinvisiblecolleges.org">The Coalition of Invisible Colleges</a></li>
	<li><a href="http://coalitionofinvisiblecolleges.org/colleges/TEAM/">The Transliminal Earth Alliance Metanarrative (T.E.A.M.)</a></li>
	<li><a href="http://internetschoolofmagic.com">The Internet School of Magic</a></li>
	<li><a href="http://patreon.com/crucible">Crucible</a>, an introspective ambient game</li>
	<li><a href="http://coalitionofinvisiblecolleges.org/colleges/Ceptr">Ceptr</a>, a truly decentralized everything</li>
	<li><a href="http://internetschoolofmagic.com/hotline.php">Shaman Direct Hotline</a>, a service of the ISoM</li>
</ul>
<p style="text-indent: 0; text-align: center; margin-top: 1.25em; margin-bottom: 1.25em;">Please contact me if you are interested in helping on any of these projects, especially Ceptr.</p>
<h1>Books</h1>
<p style="text-indent: 0;">I am writing these books:</p>
<ul>
	<li>Borderline Political Conundrum</li>
	<li>Karmic Scheduling</li>
	<li>Unleashing the Numogram</li>
</ul>
<h1 id="subreddits">Subreddits</h1>
<p style="text-indent: 0;">I administer these subreddits:</p>
<ul>
	<li><a href="http://reddit.com/r/sorceryofthespectacle">/r/sorceryofthespectacle</a>, a subreddit about critical theory, the neoliberal spectacle, virulent media narratives, and critical occultism</li>
	<li><a href="http://reddit.com/r/occult">/r/occult</a>, a large community for discussion of occult science</li>
	<li><a href="http://reddit.com/r/criticalactivism">/r/criticalactivism</a>, a place to critically examine and enact solutions to world problems</li>
	<li><a href="http://reddit.com/r/SotSExperimentalTVtm">/r/SotSExperimentalTVtm</a>, a TV channel for /r/sorceryofthespectacle, containing weird and esoteric videos</li>
	<li><a href="http://reddit.com/r/Reading1000plateaus">/r/Reading1000plateaus</a>, an open reading group for Deleuze &amp; Guattari's <em>A Thousand Plateaus</em>.</li>
	<li><a href="http://reddit.com/r/toroidalmetaphysics">/r/toroidalmetaphysics</a>, an investigation into the toroidal shape of experience</li>
	<li><a href="http://reddit.com/r/AskCriticalTheory">/r/AskCriticalTheory</a>, a place to ask questions about critical theory</li>
</ul>
<h2>Further writing</h2>
<p style="text-indent: 0;">These books are longer-term projects:</p>
<ul>
	<li>A collection of sci-fi short stories</li>
	<li>The Politics of Reality: Collected Writings</li>
	<li>Comparative Qabalism</li>
	<li>(a)telic field theory</li>
	<li>Illuminati Dialectics: Tribal Politics in a (Post)Postmodern Age</li>
	<li>Umbra, or, Mr. Pine and Mr. Clout's Delightful Adventure (long-term novel project)</li>
	<li>Sapience: Healing Self-Awareness</li>
	<li>Evocativity: Phonomorphics and Effective Speech—Omniglossia and Philologia</li>
</ul>
<?php include("footer.php"); ?>