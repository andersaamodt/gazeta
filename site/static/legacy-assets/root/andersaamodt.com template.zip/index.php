<?php include("header.php"); ?>
<?php include("banner.php"); ?>

<h1>Contact Me</h1>
<p>This website is the hub of my online presence. Telegram is the best way to contact me.</p>
<table style="margin-left: auto; margin-right: auto;">
	<tr>
		<td><strong>Telegram:</strong></td>
		<td><a href="http://telegram.me/deicidus">@deicidus</a></td>
		<td>Preferred</td>
	</tr>
	<tr>
		<td><strong>Email:</strong></td>
		<td><a href="mailto:anders.aamodt@gmail.com">anders.aamodt@gmail</a></td>
		<td></td>
	</tr>
	<tr>
		<td><strong>reddit:</strong></td>
		<td><a href="http://reddit.com/u/raisondecalcul">/u/raisondecalcul</a></td>
		<td>See <a href="projects.php#subreddits">subreddits</a></td>
	</tr>
	<tr>
		<td><strong>Facebook:</strong></td>
		<td><a href="http://facebook.com/anders.j.aamodt">anders.j.aamodt</a></td>
		<td></td>
	</tr>
	<tr>
		<td><strong>Phone:</strong></td>
		<td>+1-425-444-6778</td>
		<td>Emergencies only</td>
	</tr>
</table>
<h2>Other Aliases</h2>
<table style="margin-left: auto; margin-right: auto;">
	<tr>
		<td><strong>Twitter:</strong></td>
		<td><a href="http://twitter.com/CeladonWave">@CeledonWave</a></td>
		<td>Updated infrequently</td>
	</tr>
	<tr>
		<td><strong>Google+:</strong></td>
		<td><a href="https://plus.google.com/104699874398139833774/about">+AndersAamodt</a></td>
		<td>Updated infrequently</td>
	</tr>
	<tr>
		<td><strong>Tumblr:</strong></td>
		<td><a href="http://profoundjargon.tumblr.com">profoundjargon</a></td>
		<td>Updated infrequently</td>
	</tr>
</table>
<?php include("footer.php"); ?>